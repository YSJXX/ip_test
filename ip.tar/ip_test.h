#pragma once

void allprint();

