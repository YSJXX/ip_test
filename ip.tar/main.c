#include "ip_test.h"


int main()
{
	allprint();

	return 0;
}
